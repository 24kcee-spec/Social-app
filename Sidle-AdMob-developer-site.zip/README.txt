Sidle developer site for Firebase Hosting Spark (free quotas; no paid upgrade).
This bundle has not been deployed. Compare app-ads.txt with your AdMob console row before publishing.
From this directory on your own computer:
  npx --yes firebase-tools@latest login
  npx --yes firebase-tools@latest deploy --only hosting --project YOUR_FIREBASE_PROJECT_ID
Use the assigned PROJECT_ID.web.app address in your supported-store developer website field.
No server credentials are included. Store review, real privacy notice and live release eligibility remain necessary.
